<?php
class m_Barang extends CI_Model{
    public function __construct(){
      $this->load->database();
      $this->load->library('encryption');
    }

    public function get(){   
      return $this->db->get("barang");
    }
  
  public function updateBarang($id_barang,$data){
    $this->db->where('id_barang',$id_barang);
    return $this->db->update('barang',$data);
}

function input_data($data){
  $this->db->insert('barang',$data);
  return $this->db->insert_id();
}

public function duatabel(){
  $this->db->select('*');
  $this->db->from('barang'); 
  $this->db->join('pesan', 'pesan.id_pesan=barang.id_pesan');
  // $this->db->where('id_pesan',$id_pesan);
  // $this->db->where('status_pesan',$id_pesan);
  $this->db->where('status_pesan','Dalam Proses');
  $query = $this->db->get(); 
  return $query->result();
}

public function getStatusPesan(){
  $this->db->select('*');
  $this->db->from('barang'); 
  $this->db->join('pesan', 'pesan.id_pesan=barang.id_pesan');
  // $this->db->where('id_pesan',$id_pesan);
  // $this->db->where('status_pesan',$id_pesan);
  $this->db->where('status_pesan !=' ,'Dalam Proses');
  $query = $this->db->get(); 
  return $query->result();
}

  

  public function getDataById($id_barang){
		$this->db->select("*");
		$this->db->from("barang");
    $this->db->where('id_barang');
		$data = $this->db->get();
		return $data->result_array();	
	}

    
    

    // public function tambahUser($data){
    //     return $this->db->insert("barang",$data);
    // }

    public function hapusBarang($id_barang){
      $this->db->where('id_barang',$id_barang);
      return $this->db->delete('barang');
	}

  public function getbyidpesan($id_barang){
      $this->db->where('id_barang', $id_barang);

      return $this->db->get('barang')->result_array();
  }

  public function get_byid($id){
      $this->db->where('id', $id);

      return $this->db->get('barang')->result_array();
  }

  public function get_byPesanan($id_pesan){
      $this->db->where('id_pesan', $id_pesan);

      return $this->db->get('barang')->result_array();
  }

  public function confirm_pesanan($id_barang){
    $data = array(
      'tersedia' => 1,
    );

    $this->db->where('id_barang', $id_barang);

    return $this->db->update('barang', $data);
  }
  
  public function batalkan_pesanan($id_barang){
    $data = array(
      'tersedia' => 2,
    );

    $this->db->where('id_barang', $id_barang);

    return $this->db->update('barang', $data);
  }
}


?>