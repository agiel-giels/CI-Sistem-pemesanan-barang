<div class="box" style="color:black">

    <div class="table">
        <!-- Datatables -->
        <div class="col-lg-11">
            <div class="card mb-4">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                    <h3 class="m-0 font-weight-bold text-primary">Menu History Pesanan</h3>
                </div>

                <div class="table-responsive p-3">

                    <table class="table align-items-center table-flush" id="dataTable">
                        <thead class="thead-light">
                            <tr>

                                <th>ID Pesanan</th>
                                <th>Status Pesanan</th>
                                <th>Tanggal</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <?php
                foreach ($pesan as $data) { ?>
                        <tr>
                            <td><?php echo $data['id_pesan'] ?></td>
                            <?php if ($data['status_pesan'] == 0){ ?>
                                <td class='btn btn-primary'>Menunggu checkout</td>
                            <?php } else if ($data['status_pesan'] == 1){  ?>
                                <td class='btn btn-primary'>Menunggu Diproses</td>
                            <?php } else if ($data['status_pesan'] == 2){  ?>
                                <td class='btn btn-primary'>Diproses</td>
                            <?php } else if ($data['status_pesan'] == 3){  ?>
                                <td class='btn btn-primary'>Dikirim</td>
                            <?php } else if ($data['status_pesan'] == 4){  ?>
                                <td class='btn btn-primary'>Selesai</td>
                            <?php } ?>
                            <td><?php echo $data['tgl_pesan'] ?></td>
                            <td>
                                <div class="btn-group text-white" role="group">
                                    <div type="button" class="btn btn-danger">
                                        <a href="<?php echo base_url('index.php/customer/c_Pelanggan/detail_pesanan/'.$data['id_pesan']) ?>">
                                            <i class="far fa-eye text-white"></i>
                                    </div>
                                </div>
                            </td>
                        </tr>
                        <?php } ?>