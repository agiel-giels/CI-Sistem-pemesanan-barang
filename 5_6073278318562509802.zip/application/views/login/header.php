<!DOCTYPE html>
<html lang="en" dir="ltr">
<head>
    <meta charset="utf-8">
    <title>Menu Login</title>
    <script type="text/javascript" src="<?php echo base_url('assets/js/jquery-3.6.0.min.js'); ?>"></script>    
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/bootstrap.min.css'); ?>">
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/fonts/font-awesome.min.css'); ?>">
    <script type="text/javascript" src="<?php echo base_url('assets/js/sweetalert2.all.js'); ?>"></script> 

    <link rel="stylesheet" href="<?php echo base_url('assets/css/login_style.css'); ?>">
</head>


<body class="bg-light">