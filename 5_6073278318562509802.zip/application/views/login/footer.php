<div class="error" data-flashdata="<?= $this->session->flashdata('error');?>"></div>
<div class="success" data-flashdata="<?= $this->session->flashdata('success');?>"></div>

 <script type="text/javascript" src="<?php echo base_url('assets/js/alert.js'); ?>"></script></script>

 </div>
 </body>
 </html>