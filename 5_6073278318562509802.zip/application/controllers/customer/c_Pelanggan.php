<?php

class c_Pelanggan extends CI_Controller{

    function __construct(){
        parent::__construct();		
        $this->load->model('m_Customer','', TRUE);
        $this->load->model('m_User','',TRUE);
        $this->load->model('m_Barang','',TRUE);
        $this->load->model('m_Pesan','',TRUE);
    }

    function index(){
        $id = $this->session->userdata('id');

        $id_pesan = $this->m_Pesan->cek_pesan_aktif();

        if ($id_pesan) {
            $data['pesan'] = $this->m_Barang->get_byPesanan($id_pesan);
        }else {
            $id_baru = $this->m_Pesan->buat_baru();

            $data['pesan'] = $this->m_Barang->get_byPesanan($id_baru);
        }

        $this->load->view('customer/header');
        $this->load->view('customer/barangCust', $data);
    }

    function suratJalan(){
        $data = array(
            'id_pesanan' => $this->m_Pesan->get_byid($this->session->userdata('id')),
        );

        $this->load->view('customer/header');
        $this->load->view('customer/suratJalan', $data);
    }

    function proses_suratJalan(){
            $this->load->library('dompdf_gen');
            $user = $this->session->userdata('id');
            $id_pesanan = $this->input->post('id_pesanan');
        
            $data = array(
                    'title' => 'Laporan Barang',
                    'barang' => $this->m_Barang->get_byPesanan($id_pesanan),
                    'date' => date('d - M - Y'),
                    'user' => $user
                );
        
            $this->load->view('customer/v_SuratJalan', $data);
        
            $paper_size = 'A4';
            $orientation = 'portrait';
            $html = $this->output->get_output();
            $this->dompdf->set_paper($paper_size, $orientation);
        
            $this->dompdf->load_html($html);
            // $this->dompdf->render();
            $this->dompdf->stream("Surat_Jalan.pdf", array('Attachment'=>0 ));
    }

    function tampilPemesanan(){
        $id = $this->session->userdata('id');

        $this->load->view('customer/header');
        $this->load->view('customer/v_pemesanan_barang');
    }

    function tambah(){
        $id = $this->session->userdata('id');
        $nama_barang = $this->input->post('nama_barang');
		$jenis_barang = $this->input->post('jenis_barang');
		$tahun_pembuatan = $this->input->post('tahun_pembuatan');
        $qty = $this->input->post('qty');
        $harga = $this->input->post('harga');
        $tgl_pesan = $this->input->post('DATE');
        
        $cek_pesanan = $this->m_Pesan->cek_pesan_aktif();

        if($cek_pesanan){
            $data = array(
                'id' => $id,
                'id_pesan' => $cek_pesanan,
                'nama_barang' => $nama_barang,
                'jenis_barang' => $jenis_barang,
                'tahun_pembuatan' => $tahun_pembuatan,
                'qty' => $qty,
                'harga' => $harga,
            );

            $this->m_Barang->input_data($data);
        }else{
            $id_pesan = $this->m_Pesan->buat_baru();

            $data = array(
                'id' => $id,
                'id_pesan' => $id_pesan,
                'nama_barang' => $nama_barang,
                'jenis_barang' => $jenis_barang,
                'tahun_pembuatan' => $tahun_pembuatan,
                'qty' => $qty,
                'harga' => $harga,
            );

            $this->m_Barang->input_data($data);
        }
        
        redirect('customer/c_Pelanggan');
    }


    public function cetaklaporan()
	{
    $this->load->library('dompdf_gen');
    $user = $this->session->userdata('login_session')['username'];

    $data = array(
			'title' => 'Laporan Barang',
			'barang' => $this->barang_model->datalaporan()->result(),
			'date' => date('d - M - Y'),
      'user' => $user
		);

    $this->load->view('laporanbrg/cetaklaporanbrg', $data);

    $paper_size = 'A4';
    $orientation = 'portrait';
    $html = $this->output->get_output();
    $this->dompdf->set_paper($paper_size, $orientation);

    $this->dompdf->load_html($html);
    $this->dompdf->render();
    $this->dompdf->stream("Laporan_Barang_Inventaris.pdf", array('Attachment'=>0 ));
	}

    function list_pesanan(){ 
        $id = $this->session->userdata('id');
        $data2['pesan'] = $this->m_Barang->get_byid($id);
        $this->load->view('customer/header');
        $this->load->view('customer/barangCust', $data2);
    }

    public function delete_barang($id_barang){
        $this->m_Barang->hapusBarang($id_barang);

        redirect('customer/c_Pelanggan');
    }

    public function history_pesanan(){
        $id = $this->session->userdata('id');
        $data2['pesan'] = $this->m_Pesan->get_byid($id);
        $this->load->view('customer/header');
        $this->load->view('customer/history', $data2);
    }

    public function detail_pesanan($id_pesanan){
        $data = array(
            'barang' => $this->m_Barang->get_byPesanan($id_pesanan),
        );

        $this->load->view('customer/header');
        $this->load->view('customer/detail_history', $data);
    }

    public function checkout(){
        $id_pesan = $this->m_Pesan->cek_pesan_aktif();

        $this->m_Pesan->checkout($id_pesan);

        redirect('customer/c_Pelanggan');
    }
}



?>