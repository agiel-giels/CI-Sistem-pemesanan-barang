<?php

class c_Admin extends CI_Controller{

    function __construct(){
        parent::__construct();		
        $this->load->model('m_auth');
        $this->load->model('m_Pesan');
        $this->load->model('m_Barang');
        $this->load->model('m_User');
    }

    function index(){
        $this->load->view('admin/header');
    }

    public function proses_pesanan($id_pesan){
        $this->m_Pesan->prosesPesanan($id_pesan);

        redirect('admin/c_Barang');
    }

    public function kirim_pesanan($id_pesan){
        $this->m_Pesan->kirimPesanan($id_pesan);

        redirect('admin/c_Barang');
    }

    public function selesai_pesanan($id_pesan){
        $this->m_Pesan->selesaiPesanan($id_pesan);

        redirect('admin/c_Barang');
    }

    public function detail_pesanan($id_pesanan){
        $data = array(
            'id_pesanan' => $id_pesanan,
            'barang' => $this->m_Barang->get_byPesanan($id_pesanan),
        );

        $this->load->view('admin/header');
        $this->load->view('admin/detail_pesanan', $data);
    }

    public function confirm_pesanan($id_barang, $id_pesanan){
        $this->m_Barang->confirm_pesanan($id_barang);

        redirect('admin/c_Admin/detail_pesanan/'.$id_pesanan);
    }

    public function batalkan_pesanan($id_barang, $id_pesanan){
        $this->m_Barang->batalkan_pesanan($id_barang);

        redirect('admin/c_Admin/detail_pesanan/'.$id_pesanan);
    }

    public function laporan(){
        $data = array(
            'barang' => $this->m_Barang->get()->result_array(),
        );

        $this->load->view('admin/header');
        $this->load->view('admin/laporan', $data);
    }
}
?>