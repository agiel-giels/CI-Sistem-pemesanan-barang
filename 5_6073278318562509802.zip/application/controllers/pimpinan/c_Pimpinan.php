<?php

class c_Pimpinan extends CI_Controller{

    function __construct(){
        parent::__construct();		
        $this->load->model('m_auth');
    }

    function index(){
        $data['user'] = $this->m_auth->tampil_data()->result();
        $this->load->view('pimpinan/header');
        
    }




}



?>